This is a list of contents.

Cleaning Text
- Directions for cleaning pasted text

mytext.csv
- Empty file used for storing cleaned text

Converter.rmd 
- R file for making a word cloud of cleaned text

Plain Text Options.txt
- List of websites with text data

Readme.txt 
- Table of contents